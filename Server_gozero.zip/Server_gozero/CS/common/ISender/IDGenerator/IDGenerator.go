package IDGenerator

import (
	"Server_gozero/CS/common/ISender/ISender"
	"context"
	"log"
	"sync"
	"sync/atomic"
)

type IDRange struct {
	Start int64
	End   int64
	Next  atomic.Int64 // 原子自增
}

// 每个业务独立的发号缓存
type bizIDCache struct {
	cache   [2]IDRange
	currIdx atomic.Int32
	mu      sync.Mutex // 用于 preload 同步
}

// 总控制器：每个 bizTag → 一个独立的发号器
type IDGenerator struct {
	rpc     ISender.IDClient
	storage sync.Map // map[string]*bizIDCache
}

// 构造函数
func NewIDGenerator(rpc ISender.IDClient) *IDGenerator {
	return &IDGenerator{rpc: rpc}
}

func (g *IDGenerator) Init(bizTag string) {
	cache := &bizIDCache{}

	id, err := g.rpc.GetID(context.Background(), &ISender.GetIDReq{BizTag: bizTag})
	if err != nil {
		panic("初始化 ID 缓存失败: " + err.Error())
	}
	cache.cache[0] = IDRange{
		Start: id.IdStart,
		End:   id.IdEnd,
	}
	cache.cache[0].Next.Store(id.IdStart)

	cache.currIdx.Store(0)
	g.storage.Store(bizTag, cache)
}

func (g *IDGenerator) NextID(bizTag string) int64 {
	for {
		val, ok := g.storage.Load(bizTag)
		if !ok {
			panic("未初始化 bizTag: " + bizTag)
		}
		biz := val.(*bizIDCache)

		curr := &biz.cache[biz.currIdx.Load()]

		id := curr.Next.Add(1) - 1 // 原子 ++

		if id < curr.End {
			// 用了一半，触发异步预取
			if id-curr.Start == (curr.End-curr.Start+1)/2 {
				go g.preload(bizTag, biz)
			}
			return id
		}

		// 当前已用尽，尝试切换
		nextIdx := (biz.currIdx.Load() + 1) % 2

		next := &biz.cache[nextIdx]
		if next.Start == 0 && next.End == 0 {
			g.preload(bizTag, biz) // 同步拉
			continue
		}
		biz.currIdx.Store(nextIdx)

	}
}
func (g *IDGenerator) preload(bizTag string, biz *bizIDCache) {
	biz.mu.Lock()
	defer biz.mu.Unlock()

	nextIdx := (biz.currIdx.Load() + 1) % 2
	next := &biz.cache[nextIdx]

	// 已经预取好了，不重复拉

	id, err := g.rpc.GetID(context.Background(), &ISender.GetIDReq{BizTag: bizTag})
	if err != nil {
		log.Println("ID 预取失败:", err)
		return
	}

	*next = IDRange{
		Start: id.IdStart,
		End:   id.IdEnd,
	}
	next.Next.Store(id.IdStart)
}
