package logic

import (
	"Server_gozero/CS/userServer/model/userModel"
	"context"
	"crypto/md5"
	"time"

	"api/internal/svc"
	"api/internal/types"
	"encoding/hex"
	"errors"
	"github.com/zeromicro/go-zero/core/stores/sqlx"

	"github.com/zeromicro/go-zero/core/logx"
)

var secret = []byte("江城路")

type RegisterLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewRegisterLogic(ctx context.Context, svcCtx *svc.ServiceContext) *RegisterLogic {
	return &RegisterLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *RegisterLogic) Register(req *types.RegisterRequest) (resp *types.RegisterResponse, err error) {
	u, err := l.svcCtx.UserModel.FindOneByPhoneNumber(l.ctx, req.PhoneNumber)
	if err != nil && !errors.Is(err, sqlx.ErrNotFound) {
		logx.Errorw("user_register_UserModel.FindOneByUsername failed", logx.Field("err", err))
		return &types.RegisterResponse{Code: 400, Msg: "内部错误"}, errors.New("内部错误")
	}
	if u != nil {
		return &types.RegisterResponse{Code: 400, Msg: "用户名已存在"}, errors.New("用户名已存在")
	}

	// 👇 密码加密
	h := md5.New()
	h.Write([]byte(req.Password))
	h.Write(secret)
	passwordStr := hex.EncodeToString(h.Sum(nil))

	// 👇 构建用户对象
	user := &userModel.User{
		UserId:      l.svcCtx.IDGen.NextID("user"),
		PhoneNumber: req.PhoneNumber,
		Password:    passwordStr,
		DelTime:     time.Now(),
		CreateTime:  time.Now(),
	}

	if _, err := l.svcCtx.UserModel.Insert(context.Background(), user); err != nil {
		logx.Errorf("user_signup_UserModel.Insert failed, err:%v", err)
		return &types.RegisterResponse{Code: 400, Msg: "信息插入失败"}, err
	}
	return &types.RegisterResponse{Code: 200, Msg: "注册成功！"}, nil
}
