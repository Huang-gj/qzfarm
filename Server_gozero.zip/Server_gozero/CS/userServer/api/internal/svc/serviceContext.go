package svc

import (
	"Server_gozero/CS/common/ISender/IDGenerator"
	"Server_gozero/CS/common/ISender/id"
	"Server_gozero/CS/userServer/model/userModel"

	"Server_gozero/CS/common/ISender/ISender"

	"api/internal/config"
	"github.com/zeromicro/go-zero/core/stores/sqlx"
	"github.com/zeromicro/go-zero/zrpc"
)

type ServiceContext struct {
	Config    config.Config
	IdRpc     ISender.IDClient
	UserModel userModel.UserModel
	IDGen     *IDGenerator.IDGenerator
}

func NewServiceContext(c config.Config) *ServiceContext {
	sqlxConn := sqlx.NewMysql(c.Mysql.DataSource)
	return &ServiceContext{
		Config:    c,
		IdRpc:     id.NewID(zrpc.MustNewClient(c.IDRpc)),
		UserModel: userModel.NewUserModel(sqlxConn),
		IDGen:     IDGenerator.NewIDGenerator(id.NewID(zrpc.MustNewClient(c.IDRpc))),
	}
}
